import java.util.Scanner;

public class SimpleProduct implements Product {

	private String name;
	private String type;
	private double price;
	private int quantity;
	private boolean inStock;
	
	public SimpleProduct(){}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public boolean getInStock() {
		return inStock;
	}
	
	public void setInStock(boolean inStock) {
		this.inStock = inStock;
	}
	
	
	/**
	* readNextProduct
	*  sets SimpleProduct state to current product from scanner object
	* @param productList - scanner containing product list
	*/
	public boolean readNextProduct(Scanner productList) {
		if(productList == null)
			return false;
					
		if(productList.hasNext()){
			
			this.setName(productList.nextLine());
			this.setType(productList.nextLine());
			this.setPrice(productList.nextDouble());
			productList.nextLine();
			this.setQuantity(productList.nextInt());
			productList.nextLine();
			this.setInStock(productList.nextBoolean());
			
			if(productList.hasNext())
				productList.nextLine();

			return true;
		}
		return false;
	}
	
	public boolean equals(Object obj){
		boolean result;
		if (obj instanceof SimpleProduct) {
			SimpleProduct s1 = (SimpleProduct) obj;
			if (this.name.equals(s1.getName())
			&& this.name.equals(s1.getType())) { } result=true;
			} else { result=false; }
		return result;

		
	}
		
	
	public String toString(){
		return String.format("(%s, %s, $%.2f, %d)", this.name, this.type, this.price, this.quantity);
	}
	
	
}
