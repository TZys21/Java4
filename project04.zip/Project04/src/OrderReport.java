import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class OrderReport {

	public static void main(String[] args) throws FileNotFoundException {
		ArrayList <SimpleProduct> prodList = new ArrayList <SimpleProduct>();
		Queue <SimpleProduct> inStockList = new LinkedList <SimpleProduct>();
		Stack <SimpleProduct> outOfStockList = new Stack <SimpleProduct>();

		System.out.print("Enter database filename: ");
		Scanner inScanner = new Scanner(System.in);
		
		String inFile = inScanner.nextLine();
        SimpleProduct obj = new SimpleProduct();
        
        try{
        	File file = new File(inFile);
            Scanner inputFile = new Scanner(file);
            CustomerInfo cust1 = new CustomerInfo();
            cust1 = setCustomer(inputFile);
            int counter = 0;
            while(inputFile.hasNext())//while loop that adds all of the product elements in the input file into appropriate indexes of the ArrayList<SampleProduct> 
       		{
        	
        		prodList.add(counter, new SimpleProduct());
        		prodList.get(counter).setName(inputFile.nextLine());
        		prodList.get(counter).setType(inputFile.nextLine());
        		prodList.get(counter).setPrice(inputFile.nextDouble());
        		inputFile.nextLine();	
        		prodList.get(counter).setQuantity(inputFile.nextInt()); 
        		prodList.get(counter).setInStock(inputFile.nextBoolean());
        		
        		
        		
        		counter ++;
        		if (inputFile.hasNext())inputFile.nextLine();
        		
        		
       		}
            inputFile.close();
            
            sortStockedItems(prodList,inStockList,outOfStockList);
            double inStockSubtotal = getInStockSubtotal(inStockList);
            double outOfStockSubtotal = getOutOfStockSubtotal(outOfStockList);
            
            double taxValue = (cust1.gettaxRate())*inStockSubtotal;
            double totalCostInStock = taxValue + inStockSubtotal;
            double shippingCost = getShippingCost (totalCostInStock);
            
            System.out.println();
            System.out.println("Shipping To: ");
            System.out.println("        " + cust1.getfName() + " " + cust1.getlName());
            System.out.println("        " + cust1.getAddress());
            System.out.println("        " + cust1.getCity() + " "+ cust1.getState() + " " + cust1.getZip());
            System.out.println("-------------------------------------------------------------------------------");
            printInStockItems(inStockList);
            System.out.println(" ----------------------------------------------------------------------------- ");
            System.out.print("Subtotal:                                           ");
            System.out.printf("%.2f", inStockSubtotal);
            System.out.println();
            System.out.print("Sales Tax:                                          ");
            System.out.printf("%.2f",taxValue );
            System.out.println();
            System.out.print("Shipping:                                           " );
            System.out.printf("%.2f",shippingCost);
            System.out.println();
            double total = totalCostInStock + shippingCost;
            System.out.println(" ----------------------------------------------------------------------------- ");
            System.out.print("Total:                                              ");
            System.out.printf("%.2f",total);
            System.out.println();
            System.out.println(" ----------------------------------------------------------------------------- ");
            System.out.println();
            System.out.println("Orders Outstanding For: ");
            System.out.println("        " + cust1.getfName() + " " + cust1.getlName());
            System.out.println("        " + cust1.getAddress());
            System.out.println("        " + cust1.getCity() + " "+ cust1.getState() + " " + cust1.getZip());
            System.out.println("-------------------------------------------------------------------------------");
            printOutOfStockItems(outOfStockList);
            System.out.println(" ----------------------------------------------------------------------------- ");
            System.out.print("Outstanding Balance:                                ");
            System.out.printf("%.2f",outOfStockSubtotal);
            System.out.println();
            System.out.println("-------------------------------------------------------------------------------");
            
        }
            catch (IOException e) {
    			System.out.println("There was a problem in main");
    		}	
	}
        public static void sortStockedItems (ArrayList <SimpleProduct> aList, Queue <SimpleProduct> qList, Stack <SimpleProduct> sList)
    	{
    		for(int i = 0; i<aList.size(); i++)
    		{
    			SimpleProduct s = aList.get(i);
    			if(s.getInStock())
    			{
    				qList.add(s);
    			}
    			else{
    				sList.push(s);
    			}
    		}
    	}
  
         private static CustomerInfo setCustomer(Scanner inputFile) {
		 CustomerInfo c = new CustomerInfo();
		 c.setlName(inputFile.nextLine());
		 c.setfName(inputFile.nextLine());
		 c.setAddress(inputFile.nextLine());
		 c.setCity(inputFile.nextLine());
		 c.setState(inputFile.nextLine());
		 c.setZip(inputFile.nextLine());
		 c.settaxRate(inputFile.nextDouble());
		 inputFile.nextLine();
		 return c;
	}
         
         public static Double getInStockSubtotal (Queue <SimpleProduct> qList)
     	{
     		Queue <SimpleProduct> a = new LinkedList <SimpleProduct>();
     		SimpleProduct x = new SimpleProduct();
     		double total = 0;
     		while(!(qList.isEmpty()))
     		{
     			x = qList.remove();
     			total = total + (x.getPrice()*x.getQuantity());
     			a.add(x);
     		}
     		while(!(a.isEmpty()))
     		{
     			x = a.remove();
     			qList.add(x);
     		}
     		return total;
     	}
         
         public static  Double getOutOfStockSubtotal (Stack <SimpleProduct> sList)
     	{
     		Stack <SimpleProduct> a = new Stack <SimpleProduct>();
     		SimpleProduct x = new SimpleProduct();
     		double total = 0;
     		while(!(sList.isEmpty()))
     		{
     			x = sList.pop();
     			total = total + (x.getPrice()*x.getQuantity());
     			a.push(x);
     		}
     		while(!(a.isEmpty()))
     		{
     			x = a.pop();
     			sList.push(x);
     		}
     		return total;
     	}
         
         public static Double getShippingCost (double total)
     	{
     		double shipping;
     		double rate;
     		if (total<10)
     		{
     			rate = .15;
     		}
     		else if (total<25)
     		{
     			rate = .05;
     		}
     		else{
     			rate = 0;
     		}
     		shipping = total * rate;
     		return shipping;
     	}
         
         public static void printInStockItems (Queue <SimpleProduct> inStockList)
     	
     	{
     		SimpleProduct s = new SimpleProduct();
     		while(!(inStockList.isEmpty()))
     		{
     			s = inStockList.remove();
     			int quant = s.getQuantity();
     			String name = s.getName();
     			String type = "(" + s.getType() + ")";
     			double price = s.getPrice();
     			System.out.format(" %-1.10s %-1.10s %-35.35s %-10.10s %-10.10s", quant,"x", name, type, price);
     			System.out.println();
     		}
     	}
         
         public static void printOutOfStockItems (Stack <SimpleProduct> sList)
     	
     	{
     		SimpleProduct s = new SimpleProduct();
     		while(!(sList.isEmpty()))
     		{
     			s = sList.pop();
     			int quant = s.getQuantity();
     			String name = s.getName();
     			String type = "(" + s.getType() + ")";
     			double price = s.getPrice();
     			System.out.format(" %-1.10s %-1.10s %-35.35s %-10.10s  %-10.10s", quant, "x", name, type, price);
     			System.out.println();
     		}
     	}

}
