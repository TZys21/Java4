// extra credit
public class CustomerInfo {
	
	private String lName;
	private String fName;
	private String address;
	private String city;
	private String state;
	private String zip;
	private double taxRate;

	
	public void setlName(String name) {
		lName = name;
	}
	
	public String getlName() {
		return lName;
	}
	
	public void setfName(String name) {
		fName = name;
	}
	
	public String getfName() {
		return fName;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return address;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCity() {
		return city;
	}
	

	public void setState(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getZip() {
		return zip;
	}

	public void settaxRate(Double rate) {
		if(rate>=0){
			taxRate = rate;
	}
		else{
			rate=0.0;
		}
	}

public Double gettaxRate() {
	return taxRate;
}
public String toString()
{
	String x;
	x = (this.fName + "," + this.lName + "," + this.address + ","+this.city+ ","+this.state + ","+ this.zip+ ","+ this.taxRate);
	return x;
	
}
}
